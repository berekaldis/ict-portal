<?php
// completed_cases.php - COMPLETE FIXED FILE
$page_title = 'Completed Cases';
require_once 'config/database.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

requireLogin();

$completedCases = getCompletedCases();
$message = '';
$error = '';

// ============ HANDLE FORM-BASED APPROVAL (FALLBACK) ============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_action'])) {
    $caseId = $_POST['case_id'] ?? '';
    $approved = isset($_POST['approved']) ? (int)$_POST['approved'] : 0;
    
    if ($caseId) {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("UPDATE sales_completed_cases SET approved = ?, last_updated = NOW() WHERE case_id = ?");
            $stmt->execute([$approved, $caseId]);
            
            $action = $approved ? 'Approved' : 'Unapproved';
            logAction($_SESSION['username'] ?? 'System', 'Approve Completed Case', "$action completed case $caseId");
            
            $message = "âœ… Case $caseId $action successfully!";
            $completedCases = getCompletedCases(); // Refresh the list
            
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    } else {
        $error = 'Invalid case ID';
    }
}

// ============ HANDLE AJAX APPROVAL (via POST) ============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'approve_case') {
    $caseId = $_POST['case_id'] ?? '';
    $isApproved = isset($_POST['approved']) ? (int)$_POST['approved'] : 0;
    
    if ($caseId) {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("UPDATE sales_completed_cases SET approved = ?, last_updated = NOW() WHERE case_id = ?");
            $stmt->execute([$isApproved, $caseId]);
            
            if ($isApproved) {
                logAction($_SESSION['username'] ?? 'System', 'Approve Completed Case', "Approved completed case $caseId");
                $message = "âœ… Case $caseId approved successfully!";
            } else {
                logAction($_SESSION['username'] ?? 'System', 'Unapprove Completed Case', "Unapproved completed case $caseId");
                $message = "Case $caseId unapproved successfully!";
            }
            
            $completedCases = getCompletedCases();
            
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    } else {
        $error = 'Invalid case ID';
    }
}

include 'includes/header.php';
?>

<div class="row">
    <div class="col-12 d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-0">Completed Cases</h2>
            <p class="text-muted mb-0">All completed and approved cases</p>
        </div>
        <div class="d-flex gap-2">
            <a href="export.php?type=completed" class="btn btn-success">
                <i class="fas fa-file-export"></i> Export
            </a>
            
            </a>
        </div>
    </div>
</div>

<!-- ============ SUCCESS/ERROR MESSAGES ============ -->
<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="completedTable">
                <thead>
                    <tr>
                        <th>Case ID</th>
                        <th>Date</th>
                        <th>Branch</th>
                        <th>Z Report</th>
                        <th>Cash Sales</th>
                        <th>Difference</th>
                        <th>Fixed Date</th>
                        <th>Approved</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($completedCases as $case): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($case['case_id']) ?></strong></td>
                        <td><?= date('Y-m-d', strtotime($case['date'])) ?></td>
                        <td><?= htmlspecialchars($case['branch_name']) ?></td>
                        <td><?= number_format($case['z_report'], 2) ?></td>
                        <td><?= number_format($case['cash_sales'], 2) ?></td>
                        <td><?= number_format($case['difference'], 2) ?></td>
                        <td><?= $case['case_fixed_date'] ? date('Y-m-d', strtotime($case['case_fixed_date'])) : '-' ?></td>
                        <td>
                            <?php if ($case['approved']): ?>
                            <span class="badge bg-success">
                                <i class="fas fa-check-circle"></i> Approved
                            </span>
                            <?php else: ?>
                            <span class="badge bg-warning text-dark">
                                <i class="fas fa-clock"></i> Pending
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <!-- ============ APPROVAL BUTTONS ============ -->
                            <?php if ($case['approved']): ?>
                            <!-- Form-based Unapprove -->
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to Unapprove this case?')">
                                <input type="hidden" name="approve_action" value="1">
                                <input type="hidden" name="case_id" value="<?= htmlspecialchars($case['case_id']) ?>">
                                <input type="hidden" name="approved" value="0">
                                <button type="submit" class="btn btn-sm btn-warning" title="Unapprove">
                                    <i class="fas fa-undo"></i> Unapprove
                                </button>
                            </form>
                            <!-- AJAX Unapprove -->
                            <button onclick="toggleApproval('<?= $case['case_id'] ?>', 0)" 
                                    class="btn btn-sm btn-outline-warning" title="Unapprove (AJAX)">
                                <i class="fas fa-sync"></i>
                            </button>
                            <?php else: ?>
                            <!-- Form-based Approve -->
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to Approve this case?')">
                                <input type="hidden" name="approve_action" value="1">
                                <input type="hidden" name="case_id" value="<?= htmlspecialchars($case['case_id']) ?>">
                                <input type="hidden" name="approved" value="1">
                                <button type="submit" class="btn btn-sm btn-success" title="Approve">
                                    <i class="fas fa-check"></i> Approve
                                </button>
                            </form>
                            <!-- AJAX Approve -->
                            <button onclick="toggleApproval('<?= $case['case_id'] ?>', 1)" 
                                    class="btn btn-sm btn-outline-success" title="Approve (AJAX)">
                                <i class="fas fa-sync"></i>
                            </button>
                            <?php endif; ?>
                            
                            <!-- View Details -->
                            <button onclick="viewCompletedCase('<?= $case['case_id'] ?>')" 
                                    class="btn btn-sm btn-info" title="View Details">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($completedCases)): ?>
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                            <h5>No completed cases found</h5>
                            <p class="text-muted">Cases marked as "Done" will appear here automatically.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- View Case Modal -->
<div class="modal fade" id="viewCaseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Case Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="caseDetailsBody">
                <div class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
// ============ TOGGLE APPROVAL (AJAX METHOD) ============
function toggleApproval(caseId, approved) {
    const action = approved ? 'Approve' : 'Unapprove';
    const confirmMsg = `Are you sure you want to ${action} this case?`;
    
    if (!confirm(confirmMsg)) {
        return;
    }
    
    // Show loading state on all buttons for this case
    const buttons = document.querySelectorAll(`button[onclick*="toggleApproval('${caseId}'"]`);
    buttons.forEach(btn => {
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>';
        btn.disabled = true;
    });
    
    // Send AJAX request
    fetch('api.php?action=approve_completed_case', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            case_id: caseId, 
            approved: approved 
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Reload the page to show updated status
            window.location.reload();
        } else {
            alert('Failed to ' + action.toLowerCase() + ' case: ' + (data.error || 'Unknown error'));
            // Reset buttons
            buttons.forEach(btn => {
                btn.innerHTML = approved ? '<i class="fas fa-check"></i>' : '<i class="fas fa-undo"></i>';
                btn.disabled = false;
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while processing your request.');
        // Reset buttons
        buttons.forEach(btn => {
            btn.innerHTML = approved ? '<i class="fas fa-check"></i>' : '<i class="fas fa-undo"></i>';
            btn.disabled = false;
        });
    });
}

// ============ VIEW COMPLETED CASE ============
function viewCompletedCase(caseId) {
    // Show modal with loading
    const modal = new bootstrap.Modal(document.getElementById('viewCaseModal'));
    const body = document.getElementById('caseDetailsBody');
    body.innerHTML = `
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading case details...</p>
        </div>
    `;
    modal.show();
    
    // Fetch case details
    fetch('api.php?action=get_completed_case', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ case_id: caseId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const c = data.case;
            body.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Case ID:</strong> ${c.case_id}</p>
                        <p><strong>Date:</strong> ${c.date}</p>
                        <p><strong>Branch:</strong> ${c.branch_name}</p>
                        <p><strong>Z Report:</strong> ${parseFloat(c.z_report).toFixed(2)} ETB</p>
                        <p><strong>Cash Sales:</strong> ${parseFloat(c.cash_sales).toFixed(2)} ETB</p>
                        <p><strong>Difference:</strong> ${parseFloat(c.difference).toFixed(2)} ETB</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Progress:</strong> ${c.progress}</p>
                        <p><strong>Fixed Date:</strong> ${c.case_fixed_date || 'N/A'}</p>
                        <p><strong>Submitted By:</strong> ${c.submitted_by || 'N/A'}</p>
                        <p><strong>Technical Name:</strong> ${c.technical_name || 'N/A'}</p>
                        <p><strong>Remark:</strong> ${c.remark || 'N/A'}</p>
                        <p><strong>Approved:</strong> ${c.approved ? 'âœ… Yes' : 'âŒ No'}</p>
                    </div>
                </div>
            `;
        } else {
            body.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    Failed to load case details: ${data.error || 'Unknown error'}
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        body.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> 
                An error occurred while loading case details.
            </div>
        `;
    });
}

// ============ DATATABLE INITIALIZATION ============
$(document).ready(function() {
    $('#completedTable').DataTable({
        order: [[1, 'desc']],
        pageLength: 25,
        columnDefs: [
            { orderable: false, targets: [8] }
        ],
        language: {
            search: "Search:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ completed cases",
            infoEmpty: "No completed cases found",
            infoFiltered: "(filtered from _MAX_ total cases)",
            zeroRecords: "No matching cases found"
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?>
