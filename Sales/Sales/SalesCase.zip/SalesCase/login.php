<?php
// login.php - MODERN DESIGN
require_once 'config/database.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// If already logged in, redirect based on role
if (isLoggedIn()) {
    if (isAdmin()) {
        header('Location: dashboard.php');
    } elseif (isSupportTeam()) {
        header('Location: cases.php');
    } elseif (isFinanceTeam()) {
        header('Location: cases.php');
    } else {
        header('Location: dashboard.php');
    }
    exit();
}

$error = '';
$success = '';

// Get logo from settings
$logoUrl = getSetting('logo_url', '');
$logoFile = getSetting('logo_file', '');
$logo = !empty($logoFile) ? $logoFile : $logoUrl;
$logoSize = getSetting('logo_size', 'medium');

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        $result = login($username, $password);
        if ($result['success']) {
            if (isset($result['isFirstLogin']) && $result['isFirstLogin']) {
                $_SESSION['first_login'] = true;
                $_SESSION['temp_username'] = $username;
                header('Location: change_password.php');
                exit();
            }
            
            $role = $_SESSION['role'] ?? 'Finance Team';
            if ($role === 'Admin') {
                header('Location: dashboard.php');
            } else {
                header('Location: cases.php');
            }
            exit();
        } else {
            $error = $result['error'] ?? 'Invalid username or password';
        }
    }
}

// Check for session messages
$sessionMessage = '';
if (isset($_GET['session']) && $_GET['session'] === 'expired') {
    $sessionMessage = 'Your session has expired. Please login again.';
}
if (isset($_GET['logout']) && $_GET['logout'] === 'success') {
    $sessionMessage = 'You have been logged out successfully.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Kaldis Coffee Case Management System</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* ========================================
           MODERN LOGIN PAGE - #006A6A + #FFFCF6
           ======================================== */
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #FFFCF6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Animated Background */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: 
                radial-gradient(ellipse at 20% 50%, rgba(0, 106, 106, 0.05) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 50%, rgba(0, 136, 136, 0.05) 0%, transparent 60%),
                radial-gradient(ellipse at 50% 100%, rgba(0, 106, 106, 0.03) 0%, transparent 50%);
            animation: backgroundFloat 20s ease-in-out infinite;
            z-index: 0;
        }
        
        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            33% { transform: translate(2%, -2%) rotate(1deg); }
            66% { transform: translate(-2%, 2%) rotate(-1deg); }
        }
        
        /* Floating Decorations */
        .decoration {
            position: fixed;
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
            opacity: 0.3;
        }
        
        .decoration-1 {
            width: 300px;
            height: 300px;
            top: -100px;
            right: -100px;
            background: radial-gradient(circle, rgba(0, 106, 106, 0.08), transparent);
            animation: floatDecor 15s ease-in-out infinite;
        }
        
        .decoration-2 {
            width: 200px;
            height: 200px;
            bottom: -50px;
            left: -50px;
            background: radial-gradient(circle, rgba(0, 136, 136, 0.06), transparent);
            animation: floatDecor 20s ease-in-out infinite reverse;
        }
        
        .decoration-3 {
            width: 150px;
            height: 150px;
            top: 50%;
            left: -75px;
            background: radial-gradient(circle, rgba(0, 106, 106, 0.04), transparent);
            animation: floatDecor 18s ease-in-out infinite 2s;
        }
        
        @keyframes floatDecor {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(20px, -20px) scale(1.1); }
        }
        
        /* Login Wrapper */
        .login-wrapper {
            width: 100%;
            max-width: 440px;
            animation: slideUp 0.8s cubic-bezier(0.22, 1, 0.36, 1);
            position: relative;
            z-index: 1;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(40px) scale(0.96);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        /* Login Container */
        .login-container {
            background: #ffffff;
            border-radius: 32px;
            padding: 48px 40px 40px;
            box-shadow: 
                0 30px 80px rgba(0, 106, 106, 0.10),
                0 10px 30px rgba(0, 106, 106, 0.06),
                0 0 0 1px rgba(0, 106, 106, 0.04);
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(20px);
            transition: all 0.4s ease;
        }
        
        .login-container:hover {
            box-shadow: 
                0 40px 100px rgba(0, 106, 106, 0.12),
                0 10px 30px rgba(0, 106, 106, 0.06),
                0 0 0 1px rgba(0, 106, 106, 0.04);
        }
        
        /* Top Accent Bar */
        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #006A6A, #00AAAA, #008888, #006A6A);
            background-size: 300% 100%;
            animation: shimmer 4s ease-in-out infinite;
        }
        
        @keyframes shimmer {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        /* Corner Decorations */
        .login-container::after {
            content: '';
            position: absolute;
            bottom: -60px;
            right: -60px;
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(0, 106, 106, 0.03), transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        
        /* Brand Section */
        .login-brand {
            text-align: center;
            margin-bottom: 32px;
            position: relative;
            z-index: 1;
        }
        
        .login-brand .logo-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .login-brand .logo-image {
            max-height: 72px;
            width: auto;
            object-fit: contain;
            transition: transform 0.4s ease;
            filter: drop-shadow(0 4px 12px rgba(0, 106, 106, 0.15));
        }
        
        .login-brand .logo-image:hover {
            transform: scale(1.05);
        }
        
        .login-brand .logo-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #006A6A, #008888);
            border-radius: 24px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 2.8rem;
            box-shadow: 0 12px 40px rgba(0, 106, 106, 0.25);
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }
        
        .login-brand .logo-icon::after {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, transparent 40%, rgba(255,255,255,0.1) 60%, transparent 80%);
            transform: rotate(45deg);
        }
        
        .login-brand .logo-icon:hover {
            transform: scale(1.05) rotate(-3deg);
            box-shadow: 0 16px 50px rgba(0, 106, 106, 0.35);
        }
        
        .login-brand h2 {
            font-weight: 800;
            font-size: 1.8rem;
            color: #1A2E2E;
            margin: 0;
            letter-spacing: -0.5px;
        }
        
        .login-brand h2 span {
            background: linear-gradient(135deg, #006A6A, #008888);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .login-brand .subtitle {
            color: #8B9A9A;
            font-size: 0.9rem;
            margin-top: 6px;
            font-weight: 400;
            letter-spacing: 0.3px;
        }
        
        .login-brand .subtitle i {
            color: #006A6A;
            margin: 0 6px;
            font-size: 0.6rem;
            -webkit-text-fill-color: #006A6A;
        }
        
        /* Role Info */
        .role-info {
            background: linear-gradient(135deg, #F0F7F7, #E8F4F4);
            border-radius: 16px;
            padding: 14px 20px;
            margin-bottom: 24px;
            border-left: 4px solid #006A6A;
            position: relative;
            z-index: 1;
            transition: all 0.3s ease;
        }
        
        .role-info:hover {
            transform: translateX(4px);
            box-shadow: 0 4px 16px rgba(0, 106, 106, 0.08);
        }
        
        .role-info i {
            color: #006A6A;
            margin-right: 8px;
        }
        
        .role-info strong {
            color: #006A6A;
            font-weight: 600;
        }
        
        .role-info .demo-credentials {
            display: flex;
            flex-wrap: wrap;
            gap: 8px 16px;
            margin-top: 4px;
            font-size: 0.8rem;
        }
        
        .role-info .demo-credentials .cred {
            background: rgba(0, 106, 106, 0.08);
            padding: 2px 10px;
            border-radius: 12px;
            color: #005555;
            font-weight: 500;
        }
        
        /* Form Groups */
        .form-group {
            margin-bottom: 20px;
            position: relative;
            z-index: 1;
        }
        
        .form-group label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #2C3E3E;
            margin-bottom: 6px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group label i {
            color: #006A6A;
            width: 18px;
            font-size: 0.9rem;
        }
        
        /* Input Group */
        .input-group-custom {
            position: relative;
            transition: all 0.3s ease;
        }
        
        .input-group-custom .form-control {
            padding: 14px 16px 14px 46px;
            border: 2px solid #E8EEEE;
            border-radius: 14px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            background: #FAFCFC;
            height: 54px;
            color: #1A2E2E;
            font-weight: 500;
        }
        
        .input-group-custom .form-control::placeholder {
            color: #B0C0C0;
            font-weight: 400;
        }
        
        .input-group-custom .form-control:focus {
            border-color: #006A6A;
            box-shadow: 0 0 0 4px rgba(0, 106, 106, 0.08), 0 4px 16px rgba(0, 106, 106, 0.04);
            background: #ffffff;
            transform: translateY(-1px);
        }
        
        .input-group-custom .form-control.is-invalid {
            border-color: #DC3545;
            box-shadow: 0 0 0 4px rgba(220, 53, 69, 0.08);
        }
        
        .input-group-custom .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #B0C0C0;
            font-size: 1.1rem;
            pointer-events: none;
            transition: all 0.3s ease;
        }
        
        .input-group-custom .form-control:focus + .input-icon {
            color: #006A6A;
        }
        
        .input-group-custom .form-control.is-invalid + .input-icon {
            color: #DC3545;
        }
        
        .input-group-custom .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #B0C0C0;
            cursor: pointer;
            padding: 8px;
            transition: all 0.3s ease;
            border-radius: 8px;
        }
        
        .input-group-custom .toggle-password:hover {
            color: #006A6A;
            background: rgba(0, 106, 106, 0.06);
        }
        
        /* Form Options */
        .form-options {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            position: relative;
            z-index: 1;
        }
        
        .form-options .form-check {
            padding-left: 0;
        }
        
        .form-options .form-check-input {
            width: 18px;
            height: 18px;
            border: 2px solid #D0D8D8;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 8px;
            transition: all 0.3s ease;
        }
        
        .form-options .form-check-input:checked {
            background-color: #006A6A;
            border-color: #006A6A;
            box-shadow: 0 0 0 4px rgba(0, 106, 106, 0.1);
        }
        
        .form-options .form-check-label {
            font-size: 0.85rem;
            color: #5A6A6A;
            cursor: pointer;
        }
        
        .form-options .forgot-link {
            font-size: 0.85rem;
            color: #006A6A;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .form-options .forgot-link:hover {
            color: #005555;
            text-decoration: underline;
        }
        
        /* Login Button */
        .btn-login {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #006A6A, #008888);
            border: none;
            border-radius: 14px;
            color: #fff;
            font-weight: 700;
            font-size: 1rem;
            letter-spacing: 0.5px;
            transition: all 0.4s ease;
            height: 54px;
            position: relative;
            overflow: hidden;
            cursor: pointer;
            box-shadow: 0 4px 16px rgba(0, 106, 106, 0.2);
        }
        
        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
            transition: left 0.6s ease;
        }
        
        .btn-login:hover::before {
            left: 100%;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 32px rgba(0, 106, 106, 0.35);
        }
        
        .btn-login:active {
            transform: translateY(0px);
            box-shadow: 0 4px 16px rgba(0, 106, 106, 0.2);
        }
        
        .btn-login i {
            margin-right: 8px;
        }
        
        .btn-login .btn-loader {
            display: none;
            width: 24px;
            height: 24px;
            border: 3px solid rgba(255,255,255,0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .btn-login.loading .btn-text {
            display: none;
        }
        
        .btn-login.loading .btn-loader {
            display: block;
        }
        
        /* Alert Styles */
        .alert-custom {
            border: none;
            border-radius: 14px;
            padding: 14px 18px;
            font-weight: 500;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideDown 0.4s ease-out;
            position: relative;
            z-index: 1;
            margin-bottom: 16px;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-danger-custom {
            background: #FEF2F2;
            color: #991B1B;
            border-left: 4px solid #DC3545;
        }
        
        .alert-success-custom {
            background: #F0FDF4;
            color: #166534;
            border-left: 4px solid #2D8A4E;
        }
        
        .alert-custom i {
            font-size: 1.2rem;
        }
        
        /* Security Badge */
        .security-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 20px;
            font-size: 0.75rem;
            color: #B0C0C0;
            position: relative;
            z-index: 1;
        }
        
        .security-badge i {
            color: #2D8A4E;
            font-size: 0.85rem;
        }
        
        .security-badge .divider {
            width: 4px;
            height: 4px;
            background: #D0D8D8;
            border-radius: 50%;
        }
        
        /* Footer */
        .login-footer {
            text-align: center;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid #E8EEEE;
            position: relative;
            z-index: 1;
        }
        
        .login-footer .text-muted {
            font-size: 0.8rem;
            color: #B0C0C0 !important;
        }
        
        .login-footer .text-muted strong {
            color: #006A6A;
            font-weight: 600;
        }
        
        .login-footer .version {
            display: inline-block;
            background: #F0F7F7;
            padding: 2px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            color: #8B9A9A;
            margin-top: 4px;
            font-weight: 500;
        }
        
        /* Responsive */
        @media (max-width: 576px) {
            .login-container {
                padding: 32px 24px 28px;
                border-radius: 24px;
            }
            
            .login-brand .logo-icon {
                width: 64px;
                height: 64px;
                font-size: 2.2rem;
                border-radius: 18px;
            }
            
            .login-brand .logo-image {
                max-height: 56px;
            }
            
            .login-brand h2 {
                font-size: 1.4rem;
            }
            
            .login-brand .subtitle {
                font-size: 0.8rem;
            }
            
            .input-group-custom .form-control {
                height: 48px;
                padding: 12px 14px 12px 40px;
                font-size: 0.9rem;
            }
            
            .input-group-custom .input-icon {
                left: 14px;
                font-size: 0.95rem;
            }
            
            .btn-login {
                height: 48px;
                font-size: 0.95rem;
                padding: 14px;
            }
            
            .role-info {
                padding: 12px 16px;
                font-size: 0.8rem;
            }
            
            .role-info .demo-credentials {
                font-size: 0.75rem;
            }
            
            .form-options {
                flex-direction: column;
                gap: 12px;
                align-items: flex-start;
            }
            
            .decoration {
                display: none;
            }
            
            .login-wrapper {
                padding: 0 8px;
            }
        }
        
        @media (max-width: 400px) {
            .login-container {
                padding: 24px 16px 20px;
                border-radius: 20px;
            }
            
            .login-brand .logo-icon {
                width: 56px;
                height: 56px;
                font-size: 1.8rem;
            }
            
            .login-brand h2 {
                font-size: 1.2rem;
            }
        }
        
        /* Success/Error animation for inputs */
        .input-group-custom .form-control.success {
            border-color: #2D8A4E;
        }
        
        .input-group-custom .form-control.success + .input-icon {
            color: #2D8A4E;
        }
        
        /* Dark mode support - optional */
        @media (prefers-color-scheme: dark) {
            body {
                background: #1A2E2E;
            }
            
            .login-container {
                background: #243838;
                box-shadow: 0 30px 80px rgba(0, 0, 0, 0.3);
            }
            
            .login-container::before {
                background: linear-gradient(90deg, #00AAAA, #008888, #006A6A, #00AAAA);
            }
            
            .login-brand h2 {
                color: #E8F0F0;
            }
            
            .login-brand .subtitle {
                color: #8BAAAA;
            }
            
            .input-group-custom .form-control {
                background: #1A2E2E;
                border-color: #3A4E4E;
                color: #E8F0F0;
            }
            
            .input-group-custom .form-control::placeholder {
                color: #6A8A8A;
            }
            
            .input-group-custom .form-control:focus {
                background: #1A2E2E;
                border-color: #006A6A;
            }
            
            .form-group label {
                color: #B0C8C8;
            }
            
            .role-info {
                background: #1A2E2E;
                border-left-color: #006A6A;
            }
            
            .login-footer {
                border-top-color: #3A4E4E;
            }
            
            .login-footer .text-muted {
                color: #6A8A8A !important;
            }
            
            .form-options .form-check-label {
                color: #8BAAAA;
            }
            
            .security-badge {
                color: #6A8A8A;
            }
            
            .login-container::after {
                background: radial-gradient(circle, rgba(0, 106, 106, 0.1), transparent 70%);
            }
        }
    </style>
</head>
<body>
    <!-- Background Decorations -->
    <div class="decoration decoration-1"></div>
    <div class="decoration decoration-2"></div>
    <div class="decoration decoration-3"></div>
    
    <div class="login-wrapper">
        <div class="login-container">
            <!-- Brand -->
            <div class="login-brand">
                <div class="logo-wrapper">
                    <?php if ($logo): ?>
                        <img src="<?= htmlspecialchars($logo) ?>" 
                             alt="Company Logo" 
                             class="logo-image <?= htmlspecialchars($logoSize) ?>"
                             onerror="this.style.display='none'; document.getElementById('fallbackLogo').style.display='inline-flex';">
                        <div id="fallbackLogo" class="logo-icon" style="display: none;">
                            <i class="fas fa-coffee"></i>
                        </div>
                    <?php else: ?>
                        <div class="logo-icon">
                            <i class="fas fa-coffee"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <h2>Kaldis <span>Coffee</span></h2>
                <div class="subtitle">
                    <i class="fas fa-circle"></i> Case Management System <i class="fas fa-circle"></i>
                </div>
            </div>
            
            <!-- Role Info -->
            <div class="role-info">
                <div>
                    <i class="fas fa-info-circle"></i>
                    <strong>Welcome Back</strong>
                </div>
                
            </div>
            
            <!-- Error/Success Messages -->
            <?php if ($error): ?>
            <div class="alert alert-custom alert-danger-custom" role="alert">
                <i class="fas fa-exclamation-circle"></i>
                <div><?= htmlspecialchars($error) ?></div>
            </div>
            <?php endif; ?>
            
            <?php if ($sessionMessage): ?>
            <div class="alert alert-custom alert-success-custom" role="alert">
                <i class="fas fa-info-circle"></i>
                <div><?= htmlspecialchars($sessionMessage) ?></div>
            </div>
            <?php endif; ?>
            
            <!-- Login Form -->
            <form method="POST" id="loginForm" autocomplete="off">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username
                    </label>
                    <div class="input-group-custom">
                        <input type="text" 
                               class="form-control <?= $error ? 'is-invalid' : '' ?>" 
                               id="username" 
                               name="username" 
                               placeholder="Enter your username"
                               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                               required 
                               autofocus>
                        <i class="fas fa-user input-icon"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <div class="input-group-custom">
                        <input type="password" 
                               class="form-control <?= $error ? 'is-invalid' : '' ?>" 
                               id="password" 
                               name="password" 
                               placeholder="Enter your password"
                               required>
                        <i class="fas fa-lock input-icon"></i>
                        <button type="button" class="toggle-password" id="togglePassword" aria-label="Toggle password visibility">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div class="form-options">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="rememberMe" name="remember_me">
                        <label class="form-check-label" for="rememberMe">
                            Remember me
                        </label>
                    </div>
                    <a href="#" class="forgot-link">Forgot Password?</a>
                </div>
                
                <button type="submit" class="btn-login" id="loginBtn">
                    <span class="btn-text">
                        <i class="fas fa-sign-in-alt"></i> Sign In
                    </span>
                    <span class="btn-loader"></span>
                </button>
            </form>
            
            <!-- Security Badge -->
            <div class="security-badge">
                <i class="fas fa-shield-alt"></i>
                <span>Secure Login</span>
                <span class="divider"></span>
                <i class="fas fa-lock"></i>
                <span>Encrypted Connection</span>
            </div>
            
            <!-- Footer -->
            <div class="login-footer">
                <div class="text-muted">
                    &copy; <?= date('Y') ?> <strong>Kaldis Coffee</strong> â€¢ All rights reserved
                </div>
                <div class="version">v2.0.0</div>
            </div>
        </div>
    </div>
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // ============ TOGGLE PASSWORD VISIBILITY ============
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');
            
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
            
            // ============ LOGIN FORM LOADING STATE ============
            const loginForm = document.getElementById('loginForm');
            const loginBtn = document.getElementById('loginBtn');
            
            loginForm.addEventListener('submit', function(e) {
                const username = document.getElementById('username').value.trim();
                const password = document.getElementById('password').value;
                
                if (!username || !password) {
                    e.preventDefault();
                    showToast('Please enter both username and password', 'error');
                    return;
                }
                
                loginBtn.classList.add('loading');
                loginBtn.disabled = true;
            });
            
            // ============ REMEMBER ME FUNCTIONALITY ============
            const rememberCheckbox = document.getElementById('rememberMe');
            const usernameInput = document.getElementById('username');
            
            // Load saved username
            const savedUsername = localStorage.getItem('savedUsername');
            if (savedUsername) {
                usernameInput.value = savedUsername;
                rememberCheckbox.checked = true;
            }
            
            // Save username when form submits
            loginForm.addEventListener('submit', function() {
                if (rememberCheckbox.checked) {
                    localStorage.setItem('savedUsername', usernameInput.value);
                } else {
                    localStorage.removeItem('savedUsername');
                }
            });
            
            // ============ TOAST NOTIFICATION ============
            function showToast(message, type = 'success') {
                // Remove existing toasts
                const existingToasts = document.querySelectorAll('.toast-custom');
                existingToasts.forEach(toast => toast.remove());
                
                const toast = document.createElement('div');
                toast.className = `toast-custom toast-${type}`;
                toast.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 14px 20px;
                    border-radius: 14px;
                    font-weight: 500;
                    font-size: 0.9rem;
                    z-index: 9999;
                    animation: slideDown 0.4s ease-out;
                    max-width: 380px;
                    box-shadow: 0 8px 30px rgba(0,0,0,0.12);
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    background: ${type === 'success' ? '#F0FDF4' : '#FEF2F2'};
                    color: ${type === 'success' ? '#166534' : '#991B1B'};
                    border-left: 4px solid ${type === 'success' ? '#2D8A4E' : '#DC3545'};
                `;
                
                toast.innerHTML = `
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}" style="font-size:1.2rem;"></i>
                    <span>${message}</span>
                    <button onclick="this.parentElement.remove()" style="
                        background: none;
                        border: none;
                        font-size: 1.2rem;
                        cursor: pointer;
                        color: ${type === 'success' ? '#166534' : '#991B1B'};
                        opacity: 0.5;
                        margin-left: auto;
                    ">&times;</button>
                `;
                
                document.body.appendChild(toast);
                
                // Auto remove after 5 seconds
                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.style.opacity = '0';
                        toast.style.transition = 'opacity 0.3s ease';
                        setTimeout(() => toast.remove(), 300);
                    }
                }, 5000);
            }
            
            // ============ KEYBOARD SHORTCUT ============
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    const active = document.activeElement;
                    if (active && (active.id === 'username' || active.id === 'password')) {
                        loginForm.dispatchEvent(new Event('submit'));
                    }
                }
            });
            
            // ============ FALLBACK LOGO ============
            const logoImage = document.querySelector('.logo-image');
            if (logoImage) {
                logoImage.addEventListener('error', function() {
                    this.style.display = 'none';
                    const fallback = document.getElementById('fallbackLogo');
                    if (fallback) {
                        fallback.style.display = 'inline-flex';
                    }
                });
            }
        });
    </script>
</body>
</html>
